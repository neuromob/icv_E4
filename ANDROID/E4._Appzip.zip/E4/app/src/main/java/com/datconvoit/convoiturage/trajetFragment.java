package com.datconvoit.convoiturage;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.HashMap;

public class trajetFragment extends Fragment implements OnMapReadyCallback, LocationListener {

    private GoogleMap mMap;

    private ArrayList<Marker> mMarkerArray = new ArrayList<Marker>();

    protected LocationManager locationManager;
    protected LocationListener locationListener;

    public static final int PERMISSION_ALL = 100;
    String[] PERMISSIONS = {
            Manifest.permission.ACCESS_NETWORK_STATE,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
    };

    Boolean hasPerm, needToClear1, needToClear2;

    ViewGroup myView;

    EditText edtPlace1, edtPlace2;
    ImageButton imgBtnGps1, imgBtnGps2;
    ImageButton imgBtnValidate1, imgBtnValidate2;

    String place1, place2;
    String keyMark1 = "firstMarker";
    String keyMark2 = "secondMarker";

    HashMap<String,Marker> hashMapMarker;

    Double latitude, longitude;

    Snackbar myScnackBar;

    String[] days = new String[]{
            "Lundi",
            "Mardi",
            "Mercredi",
            "Jeudi",
            "Vendredi",
            "Samedi"
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) {
        // Defines the xml file for the fragment
        return inflater.inflate(R.layout.activity_create_trip, parent, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {

        hasPerm = false;
        needToClear1 = false;
        needToClear2 = false;

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);

        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        locationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);

        hashMapMarker = new HashMap<>();

        myView = view.findViewById(R.id.viewCreateTrip);

        myScnackBar = Snackbar.make(view,"Il vous faut maintenant ajouter les horraires",Snackbar.LENGTH_INDEFINITE)
                .setActionTextColor(Color.YELLOW)
                .setAction("Ajouter les horraires", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        Fragment fragment;
                        fragment = new dateTimeFragment();

                        final FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                        transaction.setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out);
                        transaction.replace(getActivity().findViewById(R.id.FrameLayout).getId(), fragment);
                        transaction.addToBackStack(null);
                        transaction.commit();

                    }
                });

        edtPlace1 = view.findViewById(R.id.edtPlace1);
        edtPlace2 =  view.findViewById(R.id.edtPlace2);

        imgBtnGps1 =  view.findViewById(R.id.imgBtnGps1);
        imgBtnGps2 =  view.findViewById(R.id.imgBtnGps2);

        imgBtnGps1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Marker marker = hashMapMarker.get(keyMark1);

                if(marker != null){

                    marker.remove();
                    hashMapMarker.remove(keyMark1);
                    mMarkerArray.remove(keyMark1);

                }

                getLocation();

                createMarker("Point de Départ",true);

            }
        });

        imgBtnGps2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Marker marker = hashMapMarker.get(keyMark2);

                if(marker != null){

                    marker.remove();
                    hashMapMarker.remove(keyMark2);
                    mMarkerArray.remove(keyMark2);

                }

                getLocation();

                createMarker("Lieu d'arrivée",false);

            }
        });

        imgBtnValidate1 =  view.findViewById(R.id.imgBtnValidate1);
        imgBtnValidate2 =  view.findViewById(R.id.imgBtnValidate2);

        imgBtnValidate1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                place1 = edtPlace1.getText().toString();

                if(TextUtils.isEmpty(place1)){

                    edtPlace1.setError("Il vous faut entrer votre lieu de départ");

                }

                else {

                    Marker marker = hashMapMarker.get(keyMark1);

                    if(marker != null){

                        marker.remove();
                        hashMapMarker.remove(keyMark1);

                    }

                    if(needToClear1){

                        create_new_trip.tripInfo.putString("addr1","");

                        edtPlace1.setText("");
                        imgBtnValidate1.setBackgroundResource(R.drawable.tick);

                        needToClear1 = false;

                    }
                    else {

                        create_new_trip.tripInfo.putString("addr1",place1);

                        latitude = 44.1333;
                        longitude = 4.8;

                        needToClear1 = true;

                        createMarker("Point de Départ", true);

                        imgBtnValidate1.setBackgroundResource(R.drawable.close);

                        if(!TextUtils.isEmpty(create_new_trip.tripInfo.getString("addr2"))){

                            myScnackBar.show();

                        }

                    }

                }

            }
        });

        imgBtnValidate2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                place2 = edtPlace2.getText().toString();

                if(TextUtils.isEmpty(place2)){

                    edtPlace2.setError("Il vous faut entrer votre lieu de départ");

                }

                else{

                    Marker marker = hashMapMarker.get(keyMark2);

                    if(marker != null){

                        marker.remove();
                        hashMapMarker.remove(keyMark2);

                    }

                    if(needToClear2){

                        create_new_trip.tripInfo.putString("addr2","");

                        edtPlace2.setText("");
                        imgBtnValidate2.setBackgroundResource(R.drawable.tick);

                        needToClear2 = false;

                    }
                    else {

                        latitude = 46.1333;
                        longitude = 4.5;

                        needToClear2 = true;

                        createMarker("Lieu d'arrivée", false);

                        imgBtnValidate2.setBackgroundResource(R.drawable.close);

                        create_new_trip.tripInfo.putString("addr2",place2);

                        if(!TextUtils.isEmpty(create_new_trip.tripInfo.getString("addr1"))){

                            myScnackBar.show();

                        }

                    }

                }

            }
        });

        edtPlace1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {



            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                myScnackBar.dismiss();

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        edtPlace2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {



            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                myScnackBar.dismiss();

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        if(!hasPermissions(getActivity(), PERMISSIONS)){
            ActivityCompat.requestPermissions(getActivity(), PERMISSIONS, PERMISSION_ALL);
        }
        else {

            hasPerm = true;

            getLocation();

        }

    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
    }


    public static boolean hasPermissions(Context context, String... permissions) {
        if (context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        Boolean Perm = false;

        switch (requestCode) {
            case PERMISSION_ALL:{
                if (grantResults.length > 0) {
                    for (int i = 0; i < permissions.length; i++) {

                        if (permissions[i].equals(Manifest.permission.ACCESS_FINE_LOCATION)) {
                            if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {

                                Perm = true;

                            }
                        }

                        if (permissions[i].equals(Manifest.permission.ACCESS_COARSE_LOCATION)) {
                            if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {

                                Perm = true;

                            }
                        }

                        if (permissions[i].equals(Manifest.permission.ACCESS_NETWORK_STATE)) {
                            if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {

                                Perm = true;

                            }
                        }

                    }

                }

                hasPerm = Perm;

                return;
            }

        }

    }

    private void createMarker(String desc, Boolean isFirstMarker){

        Marker markerPos;

        if(isFirstMarker){

            markerPos = mMap.addMarker(new MarkerOptions()
                    .position(new LatLng(latitude, longitude))
                    .title(desc));

            hashMapMarker.put(keyMark1,markerPos);

        }
        else{

            markerPos = mMap.addMarker(new MarkerOptions()
                    .position(new LatLng(latitude, longitude))
                    .title(desc)
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)));

            hashMapMarker.put(keyMark2,markerPos);

        }

        mMarkerArray.add(markerPos);

        LatLngBounds.Builder builder = new LatLngBounds.Builder();

        for (Marker marker : mMarkerArray) {
            builder.include(marker.getPosition());
        }

        LatLngBounds bounds = builder.build();

        mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, 40));

    }

    @SuppressLint("MissingPermission")
    private void getLocation(){

        final LocationManager manager = (LocationManager) getActivity().getSystemService( Context.LOCATION_SERVICE );

        if ( !manager.isProviderEnabled( LocationManager.GPS_PROVIDER ) ) {
            buildAlertMessageNoGps();
        }
        else{

            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);

        }

    }

    private void buildAlertMessageNoGps() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage("Votre GPS semble désactivé, voulez-vous l'activer ?")
                .setCancelable(false)
                .setPositiveButton("Oui", new DialogInterface.OnClickListener() {
                    public void onClick(@SuppressWarnings("unused") final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                        startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                })
                .setNegativeButton("NON", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                        dialog.cancel();
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }

    @Override
    public void onLocationChanged(Location location) {

        latitude = location.getLatitude();
        longitude = location.getLongitude();

    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }

}
