package com.datconvoit.convoiturage;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.regex.Pattern;

// Classe pour gérer la page de la connection utilisateur
public class LoginActivity extends AppCompatActivity {

    // Déclaration variables pour les éléments du design de type "EditText"
    EditText emailEditText, passwordEditText;

    // Déclaration variable pour l'élément du design de type "Button"
    Button submitButton, forgotPswdButton;

    // Fonction de base s'enclenchant à la création de la page
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Attribution de cette classe au "Layout" du login, autrement dit à la page de la connection
        setContentView(R.layout.activity_login);

        // Définition des variables de type "EditText" aux éléments du "Layout" de type EditText
        // ayant pour id "editTextMail et editTextPass"
        emailEditText = findViewById(R.id.editTextMail);
        passwordEditText = findViewById(R.id.editTextPass);

        // Définition des variables de type "Button" à l'élément du "Layout" de type Button
        // ayant pour id "buttonSubmit et buttonForgotMDP
        submitButton = findViewById(R.id.buttonSubmit);
        forgotPswdButton = findViewById(R.id.buttonForgotMDP);

        // Création de l'écouteur d'événement pour le button
        // Ici il va réagir au clique du button et appelé la fonction onClick
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Déclaration et définition des variables
                // de type String prenant la valeur des champs mail et mot de passe
                String mail = emailEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                // Vérification des champs à travers la fonction checkUp plus bas
                if(checkUp(mail, password)){

                    // Si tout est OK alors on lance la connection
                    // Toute gestion d'erreur se fera à partir de cette fonction
                    connect(mail, password);

                }
                else{

                    // Sinon on ne fait rien
                    // car la fonction checkUp se charge de ce genre de cas en affichant les messages adéquats

                }

            }

        });

        // Création de l'évent pour gérer le cas du mot de pass oublié
        forgotPswdButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ViewGroup viewGroup = findViewById(android.R.id.content);

                // Appel de la view qui nous interresse pour créer la fenetre
                View  dialogView = LayoutInflater.from(LoginActivity.this).inflate(R.layout.psw_forgot_custom_alert, viewGroup, false);

                // Création du constructeur qui va afficher la fenetre
                AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);

                // Attribution de l'affichage à la fenetre
                builder.setView(dialogView);

                // Affichage de la fenetre
                AlertDialog alertDialog = builder.create();

                // Déclaration et attribution des variables
                final EditText edtForgotPswd = dialogView.findViewById(R.id.edtForgotPswd);
                Button btnForgotPswd = dialogView.findViewById(R.id.submitForgotPswd);

                // Création de l'écouteur d'événement pour le button
                // Ici il va réagir au clique du button et appelé la fonction onClick
                btnForgotPswd.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        String mail = edtForgotPswd.getText().toString();

                        if(TextUtils.isEmpty(mail)){

                            edtForgotPswd.setError("Champ obligatoire !");

                        }
                        else{

                            claimNewPassword(mail);

                        }

                    }

                });

                alertDialog.show();

            }

        });

    }

    @Override
    protected void onStart() {
        super.onStart();

        connect("test@test.fr", "1234");

    }

    // Cette fonction va vérifier que les mail et MDP ne soient pas vident et que le mail soit d'un format valide
    // Qui va prendre pour paramètres
    // STRING = emailEditText.getText().toString()
    // STRING = passwordEditText.getText().toString()
    // Ils sont tous les 2 des strings et donc le contenus des champs "mail" et "mot de passe"
    // Et renvoyer true si tout est OK
    // Sinon false si une erreur est détecté
    private Boolean checkUp(String mail, String password){

        // Déclaration et définition de la variable de type Booléan qui sera renvoyé
        // on part du principe que tout marche et cela les étapes on renvoit false
        Boolean isAllOk = true;

        // Test si mail est vide
        if(TextUtils.isEmpty(mail)){

            // Tout va mal alors on renvoie false
            isAllOk = false;

            // On affiche le message d'erreur que le champ est à remplir
            emailEditText.setError("Champ obligatoire !");

        }

        // Test si la valeur entré est bien un champ mail
        if(!Patterns.EMAIL_ADDRESS.matcher(mail).matches()){

            // Tout va mal alors on renvoie false
            isAllOk = false;

            // On affiche que l'entrée utilisateur ne correspond pas à une adresse mail
            emailEditText.setError("Format adresse mail invalide !");

        }

        // Test si le MDP a été informé
        if(TextUtils.isEmpty(password)){

            // Tout va mal alors on renvoie false
            isAllOk = false;

            // On affiche le message d'erreur que le champ est à remplir
            passwordEditText.setError("Champ obligatoire !");

        }

        // Renvoie de la réponse si tout est OK ou pas
        return isAllOk;

    }

    // Fonction de connection utilisateur
    // Qui prend pour paramètres la saisie utilisateur une fois qu'elle est validée
    // Renvoie un Boolean si tout est OK
    private void connect(String mail, String password){

        // Url pointant vers l'API et la fonction adéquate, ici ça sera la fonction de connection
        String url = new Urlbase().urlbase + "/login";

        // Création d'un JSON qui va contenir les informations nécessaire à la connection
        // Donc ça sera le mail et le password de l'utilisateur
        // Et tout sera envoyé vers le serveur
        JSONObject loginInfos = new JSONObject();
        try {
            loginInfos.put("mail", mail);
            loginInfos.put("password", password);

        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();

            // Ici on gère l'erreur qui pourrait se présenter lors de la création du JSON
            // Et on affiche dans les logs l'erreur
            Log.e("connect","error making JSON: "+e);

        }

        // On créer la requête qui sera envoyer au serveur
        // Request.Method.POST: On attribut la méthode POST
        // url: L'URL du serveur et de la fonction de l'API
        // loginInfos: Les parametre à envoyer donc le JSON
        // Et enfin l'écouteur d'événement ou si vous préférez la réponse du serveur
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.POST, url, loginInfos, new Response.Listener<JSONObject>() {

                    // Si on a une réponse alors on la  gère ici
                    @Override
                    public void onResponse(JSONObject response) {

                        // Gestion de la réponse du serveur
                        Log.e("connect","response: "+response);

                        // Gestion de la réponse du serveur
                        try {

                            Urlbase.userInfo.putInt("idUser",response.getInt("id"));
                            Urlbase.userInfo.putString("nom",response.getString("nom"));
                            Urlbase.userInfo.putString("prenom",response.getString("prenom"));
                            Urlbase.userInfo.putString("email",response.getString("email"));

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        // Ligne de code pour appeler la redirection sur une autre page
                        // Ici on part de la page LoginActivity pour aller vers HomeActivity
                        Intent goToHome = new Intent(LoginActivity.this, HomeActivity.class);
                        startActivity(goToHome);

                    }
                    // Si on a une erreur on la gère ici et on pleure car il y a une erreur qui ne devrait pas être la mais il faut la gérer pour éviter le crash complet
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {

                        // Gestion de l'erreur
                        // S'il n'y a pas de connection internet alors on va gérer l'erreur ICI
                        if (error instanceof TimeoutError || error instanceof NoConnectionError) {

                        }

                        // si l'authentification n'est pas bonne on gére l'erreur ICI
                        else if (error instanceof AuthFailureError) {
                            //TODO
                        }

                        // Si le serveur est mort alors on gere ça ICI
                        else if (error instanceof ServerError) {
                            //TODO
                        }

                        // S'il y a un problème réseau... ICI
                        else if (error instanceof NetworkError) {
                            //TODO
                        }

                        // Et enfin s'il y a un problème de code côté serveur ça sera ICI !
                        else if (error instanceof ParseError) {
                            //TODO
                        }

                    }
                });

        // Ajout e la requete à la queue pour son envoie
        Volley.newRequestQueue(LoginActivity.this).add(jsonObjectRequest);

    }

    private void claimNewPassword(String mail) {

        // Url pointant vers l'API et la fonction adéquate, ici ça sera la fonction de connection
        String url = new Urlbase().urlbase + "/claim_new_password";

        // Création d'un JSON qui va contenir les informations nécessaire à la connection
        // Donc ça sera le mail et le password de l'utilisateur
        // Et tout sera envoyé vers le serveur
        JSONObject claimNewPasswordInfos = new JSONObject();
        try {
            claimNewPasswordInfos.put("mail", mail);

        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();

            // Ici on gère l'erreur qui pourrait se présenter lors de la création du JSON
            // Et on affiche dans les logs l'erreur
            Log.e("claimNewPassword","error making JSON: "+e);

        }

        // On créer la requête qui sera envoyer au serveur
        // Request.Method.POST: On attribut la méthode POST
        // url: L'URL du serveur et de la fonction de l'API
        // loginInfos: Les parametre à envoyer donc le JSON
        // Et enfin l'écouteur d'événement ou si vous préférez la réponse du serveur
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.POST, url, claimNewPasswordInfos, new Response.Listener<JSONObject>() {

                    // Si on a une réponse alors on la  gère ici
                    @Override
                    public void onResponse(JSONObject response) {

                        // Gestion de la réponse du serveur
                        try {

                            Urlbase.userInfo.putInt("idUser",response.getInt("id"));
                            Urlbase.userInfo.putString("nom",response.getString("nom"));
                            Urlbase.userInfo.putString("prenom",response.getString("prenom"));
                            Urlbase.userInfo.putString("email",response.getString("email"));

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                    // Si on a une erreur on la gère ici et on pleure car il y a une erreur qui ne devrait pas être la mais il faut la gérer pour éviter le crash complet
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {

                        // Gestion de l'erreur ICI

                        // S'il n'y a pas de connection internet alors on va gérer l'erreur ICI
                        if (error instanceof TimeoutError || error instanceof NoConnectionError) {

                        }

                        // si l'authentification n'est pas bonne on gére l'erreur ICI
                        else if (error instanceof AuthFailureError) {
                            //TODO
                        }

                        // Si le serveur est mort alors on gere ça ICI
                        else if (error instanceof ServerError) {
                            //TODO
                        }

                        // S'il y a un problème réseau... ICI
                        else if (error instanceof NetworkError) {
                            //TODO
                        }

                        // Et enfin s'il y a un problème de code côté serveur ça sera ICI !
                        else if (error instanceof ParseError) {
                            //TODO
                        }

                    }
                });

        // Ajout e la requete à la queue pour son envoie
        Volley.newRequestQueue(this).add(jsonObjectRequest);

    }

}
