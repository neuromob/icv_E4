package com.datconvoit.convoiturage;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class create_new_trip extends AppCompatActivity {

    public static Bundle tripInfo = new Bundle();

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_coordinates:

                    Log.e("case 1","hello");

                    Fragment fragment1;
                    fragment1 = new trajetFragment();

                    final FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                    transaction.setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out);
                    transaction.replace(R.id.FrameLayout, fragment1);
                    transaction.addToBackStack(null);
                    transaction.commit();

                    return true;
                case R.id.time_date:

                    Log.e("case 2","hello");

                    Fragment fragment2;
                    fragment2 = new dateTimeFragment();

                    final FragmentTransaction transaction2 = getSupportFragmentManager().beginTransaction();
                    transaction2.setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out);
                    transaction2.replace(R.id.FrameLayout, fragment2);
                    transaction2.addToBackStack(null);
                    transaction2.commit();

                    return true;
                case R.id.navigation_car:

                    Log.e("case 3","hello");

                    Fragment fragment3;
                    fragment3 = new vehicleFragment();

                    final FragmentTransaction transaction3 = getSupportFragmentManager().beginTransaction();
                    transaction3.setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out);
                    transaction3.replace(R.id.FrameLayout, fragment3);
                    transaction3.addToBackStack(null);
                    transaction3.commit();

                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_new_trip);

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        if (savedInstanceState == null) {

            Fragment fragment = null;
            Class fragmentClass = null;
            fragment = new trajetFragment();
            fragmentClass= trajetFragment.class;

            final FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out);
            transaction.replace(R.id.FrameLayout, fragment);
            transaction.addToBackStack(null);
            transaction.commit();

        }

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

}
