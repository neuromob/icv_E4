package com.datconvoit.convoiturage;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class dateTimeFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) {
        // Defines the xml file for the fragment
        return inflater.inflate(R.layout.activity_date_time_fragment, parent, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {

        Log.e("addr1",create_new_trip.tripInfo.getString("addr1","nope1"));
        Log.e("addr2",create_new_trip.tripInfo.getString("addr2","nope2"));

    }
}
