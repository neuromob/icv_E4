package com.datconvoit.convoiturage;

public class DataModel {

    Integer id;
    Integer place;
    String day;
    String heureDepart;
    String heureArrivee;
    String villeDepart;
    String villeArrivee;

    public DataModel(Integer id, Integer place, String day, String heureDepart, String heureArrivee, String villeDepart, String villeArrivee) {

        this.id = id;
        this.place = place;
        this.heureDepart = heureDepart;
        this.day = day;
        this.heureArrivee = heureArrivee;
        this.villeDepart = villeDepart;
        this.villeArrivee = villeArrivee;
    }

    public Integer getId() {
        return id;
    }

    public Integer getPlace() {
        return place;
    }

    public String getDay() {
        return day;
    }

    public String getHeureDepart() {
        return heureDepart;
    }

    public String getHeureArrivee() {
        return heureArrivee;
    }

    public String getVilleDepart() {
        return villeDepart;
    }

    public String getVilleArrivee() {
        return villeArrivee;
    }

}
