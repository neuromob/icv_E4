package com.datconvoit.convoiturage;

import android.os.Bundle;

public class Urlbase {

    public static Bundle userInfo = new Bundle();
    String urlbase = "http://192.168.5.64/DaConv/src";
//    String urlbase = "http:/192.168.1.38/DaConv/src";

}
