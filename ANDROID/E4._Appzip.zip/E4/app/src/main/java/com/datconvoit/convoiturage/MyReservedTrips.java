package com.datconvoit.convoiturage;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MyReservedTrips extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    ArrayList<DataModel> dataModels;
    ListView listView;
    private static CustomAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_reserved_trips);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("Mes Réservations");
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // Envoie sur la page créer un nouveau trajet
                Intent goToSettings = new Intent(MyReservedTrips.this, create_new_trip.class);
                startActivity(goToSettings);

            }
        });

        // Création et configuration affichage volet gauche
        //----------------------------------------------------------------------------------------//

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);

        View headerView = navigationView.getHeaderView(0);
        TextView drawerUsername = headerView.findViewById(R.id.textViewDrawerTitle);
        TextView drawerMail = headerView.findViewById(R.id.textViewDrawerMail);

        // Changement de nom dans le drawer
        //----------------------------------------------------------------------------------------//
        String prenomNomUser = Urlbase.userInfo.getString("prenom")+ " " + Urlbase.userInfo.getString("nom");

        drawerUsername.setText(prenomNomUser);
        drawerMail.setText(Urlbase.userInfo.getString("email"));
        navigationView.setNavigationItemSelectedListener(this);

        // Attribution valeur aux variables
        listView = findViewById(R.id.list);
        dataModels = new ArrayList<>();

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.options_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_map) {

            // Envoie sur la page créer un nouveau trajet
            Intent goToMaps = new Intent(this, HomeActivity.class);
            startActivity(goToMaps);

        } else if (id == R.id.nav_my_created_travels) {

            // Envoie sur la page créer un nouveau trajet
            Intent goToMyTrips = new Intent(this, MyTrips.class);
            startActivity(goToMyTrips);

        } else if (id == R.id.nav_my_travels) {

            // On ne fait rien car nous sommes déjè sur la page

        } else if (id == R.id.nav_manage) {

            // Envoie sur la page paramètre
            Intent goToSettings = new Intent(this, SettingsActivity.class);
            startActivity(goToSettings);

        } else if (id == R.id.nav_my_messages) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    protected void onStart() {
        super.onStart();

        if(listView.getChildCount() > 0){

            dataModels.clear();

        }

        getListReservedTrips(Urlbase.userInfo.getInt("idUser"));

    }

    private void getListReservedTrips(Integer idUser){

        // Gestion de la réponse du serveur
        Log.e("getMyListOfTrips","Début");

        // Création d'un JSON qui va contenir les informations nécessaire à la connection
        // Donc ça sera le mail et le password de l'utilisateur
        // Et tout sera envoyé vers le serveur
        JSONObject userInfos = new JSONObject();
        try {
            userInfos.put("idUser", idUser);

        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();

            // Ici on gère l'erreur qui pourrait se présenter lors de la création du JSON
            // Et on affiche dans les logs l'erreur
            Log.e("getMyInfo","error making JSON: "+e);

        }

        JSONArray jsonArray = new JSONArray();

        jsonArray.put(userInfos);

        Log.e("getMyInfo",""+jsonArray);

        // Url pointant vers l'API et la fonction adéquate, ici ça sera la fonction de connection
        String url = new Urlbase().urlbase + "/getListOfReservedTrips";

        // On créer la requête qui sera envoyer au serveur
        // Request.Method.GET: On attribut la méthode GET
        // url: L'URL du serveur et de la fonction de l'API
        // loginInfos: Les parametre à envoyer donc le JSON
        // Et enfin l'écouteur d'événement ou si vous préférez la réponse du serveur
        JsonArrayRequest jsonObjectRequest = new JsonArrayRequest
                (Request.Method.POST, url, jsonArray, new Response.Listener<JSONArray>() {

                    // Si on a une réponse alors on la  gère ici
                    @Override
                    public void onResponse(JSONArray response) {

                        // Gestion de la réponse du serveur
                        Log.e("getListOfReservedTrips",""+response);

                        for(int i= 0; i<response.length(); i++){

                            try {

                                JSONObject tripData = response.getJSONObject(i);
                                dataModels.add(new DataModel(tripData.getInt("idConducteur"), tripData.getInt("placeDisponible"), tripData.getString("dateParcours"),tripData.getString("heureDepart"),
                                        tripData.getString("heureArrivee"), tripData.getString("villeDepart"), tripData.getString("villeArrivee")));

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }

                        adapter = new CustomAdapter(dataModels,getApplicationContext());

                        listView.setAdapter(adapter);
                        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            @Override
                            public void onItemClick(AdapterView<?> parent, final View view, int position, long id) {

                                Log.e("reserved","clicked");

                                final DataModel dataModel = dataModels.get(position);

                                AlertDialog.Builder builder = new AlertDialog.Builder(MyReservedTrips.this);

                                builder.setIcon(R.drawable.stop);
                                builder.setTitle("Annulation de réservation");
                                builder.setMessage("Souhaitez-vous annuler cette réservation ?");

                                builder.setPositiveButton("Oui", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        // Gestion de la suppression de trajet

                                        deleteMyReservedTrip(dataModel);
                                        dialog.dismiss();

                                        Snackbar snackbar = Snackbar
                                                .make(view, "Réservation annulé !", Snackbar.LENGTH_LONG)
                                                .setAction("ANNULER", new View.OnClickListener() {
                                                    @Override
                                                    public void onClick(View view) {

                                                        restoreReservation(dataModel);

                                                        Snackbar snackbar1 = Snackbar.make(view, "Réservation restaurée !", Snackbar.LENGTH_SHORT);
                                                        snackbar1.show();
                                                    }
                                                });

                                        snackbar.addCallback(new Snackbar.Callback() {

                                            @Override
                                            public void onDismissed(Snackbar snackbar, int event) {
                                                // Gestion event message passé


                                                // Renvoie sur la meme page pour rafraichir
                                                Intent goToMyTrips = new Intent(MyReservedTrips.this, MyReservedTrips.class);
                                                startActivity(goToMyTrips);

                                            }
                                        });

                                        snackbar.show();


                                    }
                                });
                                builder.setNegativeButton("NON", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        // Gestion de l'abandon de suppression
                                        // On fait rien car la fenetre va s'effacer d'elle même mais on peut toujours rajouter une action plus tard

                                        dialog.dismiss();

                                    }
                                });

                                AlertDialog dialog = builder.create();

                                dialog.show();

                            }
                        });
                    }
                    // Si on a une erreur on la gère ici et on pleure car il y a une erreur qui ne devrait pas être la mais il faut la gérer pour éviter le crash complet
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {

                        // Gestion de l'erreur ICI
                        Log.e("error:",""+error);

                        // S'il n'y a pas de connection internet alors on va gérer l'erreur ICI
                        if (error instanceof TimeoutError || error instanceof NoConnectionError) {

                        }

                        // si l'authentification n'est pas bonne on gére l'erreur ICI
                        else if (error instanceof AuthFailureError) {
                            //TODO
                        }

                        // Si le serveur est mort alors on gere ça ICI
                        else if (error instanceof ServerError) {
                            //TODO
                        }

                        // S'il y a un problème réseau... ICI
                        else if (error instanceof NetworkError) {
                            //TODO
                        }

                        // Et enfin s'il y a un problème de code côté serveur ça sera ICI !
                        else if (error instanceof ParseError) {
                            //TODO
                        }

                    }
                });

        // Ajout e la requete à la queue pour son envoie
        Volley.newRequestQueue(this).add(jsonObjectRequest);

    }

    private void deleteMyReservedTrip(DataModel dataModel){

        // Url pointant vers l'API et la fonction adéquate, ici ça sera la fonction de connection
        String url = new Urlbase().urlbase + "/deleteReservation";

        JSONObject userInfos = new JSONObject();
        try {
            userInfos.put("idUser", Urlbase.userInfo.getInt("idUser"));
            userInfos.put("idTrip", dataModel.getId());

        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();

            // Ici on gère l'erreur qui pourrait se présenter lors de la création du JSON
            // Et on affiche dans les logs l'erreur
            Log.e("deleteMyTrip","error making JSON: "+e);

        }

        // On créer la requête qui sera envoyer au serveur
        // Request.Method.POST: On attribut la méthode POST
        // url: L'URL du serveur et de la fonction de l'API
        // loginInfos: Les parametre à envoyer donc le JSON
        // Et enfin l'écouteur d'événement ou si vous préférez la réponse du serveur
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.POST, url, userInfos, new Response.Listener<JSONObject>() {

                    // Si on a une réponse alors on la  gère ici
                    @Override
                    public void onResponse(JSONObject response) {

                        // Gestion de la réponse du serveur
                        Log.e("updateMDP","response: "+response);

                    }
                    // Si on a une erreur on la gère ici et on pleure car il y a une erreur qui ne devrait pas être la mais il faut la gérer pour éviter le crash complet
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Log.e("volley error",""+error);

                        // Gestion de l'erreur
                        // S'il n'y a pas de connection internet alors on va gérer l'erreur ICI
                        if (error instanceof TimeoutError || error instanceof NoConnectionError) {

                        }

                        // si l'authentification n'est pas bonne on gére l'erreur ICI
                        else if (error instanceof AuthFailureError) {
                            //TODO
                        }

                        // Si le serveur est mort alors on gere ça ICI
                        else if (error instanceof ServerError) {
                            //TODO
                        }

                        // S'il y a un problème réseau... ICI
                        else if (error instanceof NetworkError) {
                            //TODO
                        }

                        // Et enfin s'il y a un problème de code côté serveur ça sera ICI !
                        else if (error instanceof ParseError) {
                            //TODO
                        }

                    }
                });

        // Ajout e la requete à la queue pour son envoie
        Volley.newRequestQueue(MyReservedTrips.this).add(jsonObjectRequest);

    }

    private void restoreReservation(DataModel dataModel){

        // Url pointant vers l'API et la fonction adéquate, ici ça sera la fonction de connection
        String url = new Urlbase().urlbase + "/restoreReservation";

        JSONObject userInfos = new JSONObject();
        try {
            userInfos.put("idUser", Urlbase.userInfo.getInt("idUser"));
            userInfos.put("idTrip", dataModel.getId());

        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();

            // Ici on gère l'erreur qui pourrait se présenter lors de la création du JSON
            // Et on affiche dans les logs l'erreur
            Log.e("deleteMyTrip","error making JSON: "+e);

        }

        // On créer la requête qui sera envoyer au serveur
        // Request.Method.POST: On attribut la méthode POST
        // url: L'URL du serveur et de la fonction de l'API
        // loginInfos: Les parametre à envoyer donc le JSON
        // Et enfin l'écouteur d'événement ou si vous préférez la réponse du serveur
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.POST, url, userInfos, new Response.Listener<JSONObject>() {

                    // Si on a une réponse alors on la  gère ici
                    @Override
                    public void onResponse(JSONObject response) {

                        // Gestion de la réponse du serveur
                        Log.e("restoreReservation","response: "+response);

                    }
                    // Si on a une erreur on la gère ici et on pleure car il y a une erreur qui ne devrait pas être la mais il faut la gérer pour éviter le crash complet
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Log.e("volley error",""+error);

                        // Gestion de l'erreur
                        // S'il n'y a pas de connection internet alors on va gérer l'erreur ICI
                        if (error instanceof TimeoutError || error instanceof NoConnectionError) {

                        }

                        // si l'authentification n'est pas bonne on gére l'erreur ICI
                        else if (error instanceof AuthFailureError) {
                            //TODO
                        }

                        // Si le serveur est mort alors on gere ça ICI
                        else if (error instanceof ServerError) {
                            //TODO
                        }

                        // S'il y a un problème réseau... ICI
                        else if (error instanceof NetworkError) {
                            //TODO
                        }

                        // Et enfin s'il y a un problème de code côté serveur ça sera ICI !
                        else if (error instanceof ParseError) {
                            //TODO
                        }

                    }
                });

        // Ajout e la requete à la queue pour son envoie
        Volley.newRequestQueue(MyReservedTrips.this).add(jsonObjectRequest);

    }

}
