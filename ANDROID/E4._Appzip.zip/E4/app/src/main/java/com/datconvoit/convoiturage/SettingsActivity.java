package com.datconvoit.convoiturage;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class SettingsActivity extends AppCompatActivity {

    EditText edtNom, edtPrenom, edtMail;
    EditText edtModel, edtBrand, edtColor, edtPlace;
    EditText edtStrtNbr, edtStrtNm, edtCity, edtCP;

    Switch hasCarAvailable;

    Button btnChangePassword, btnRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        edtNom = findViewById(R.id.edtNom);
        edtPrenom = findViewById(R.id.edtPrenom);
        edtMail = findViewById(R.id.edtMail);

        edtModel = findViewById(R.id.edtCarModel);
        edtBrand = findViewById(R.id.edtCarBrand);
        edtColor = findViewById(R.id.edtCarColor);
        edtPlace = findViewById(R.id.edtPlace);

        edtStrtNbr = findViewById(R.id.edtNumStreet);
        edtStrtNm = findViewById(R.id.edtStreet);
        edtCity = findViewById(R.id.edtCity);
        edtCP = findViewById(R.id.edtPostalCode);

        hasCarAvailable = findViewById(R.id.switchDriver);

        btnChangePassword = findViewById(R.id.btnChangePassword);
        btnRegister = findViewById(R.id.btnRegister);

        btnChangePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final Dialog dialog = new Dialog(SettingsActivity.this);
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.setContentView(R.layout.custom_dialog_alert_change_password);

                final EditText oldPwd = dialog.findViewById(R.id.edtOldPwd);
                final EditText newPwd = dialog.findViewById(R.id.edtNewPwd);
                final EditText newPwd2 = dialog.findViewById(R.id.edtNewPwd2);

                Button confirm = dialog.findViewById(R.id.btnConfirm);

                confirm.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        Boolean isEverythingOk = true;

                        String oldPassword = oldPwd.getText().toString();
                        String newPassword = newPwd.getText().toString();
                        String newPassword2 = newPwd2.getText().toString();

                        if (TextUtils.isEmpty(oldPassword)) {

                            oldPwd.setError("Champ obligatoire !");
                            isEverythingOk = false;

                        }
                        if (TextUtils.isEmpty(newPassword)) {

                            newPwd.setError("Champ obligatoire !");
                            isEverythingOk = false;

                        }
                        if (TextUtils.isEmpty(newPassword2)) {

                            newPwd2.setError("Champ obligatoire !");
                            isEverythingOk = false;

                        }
                        if (!newPassword.matches(newPassword2)) {

                            newPwd.setError("Les mots de passe ne correspondent pas");
                            newPwd2.setError("Les mots de passe ne correspondent pas");
                            isEverythingOk = false;

                        }

                        if (isEverythingOk) {

                            dialog.dismiss();
                            updateMDP(Urlbase.userInfo.getInt("idUser"), oldPassword, newPassword);


                        }

                    }
                });

                dialog.show();

            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Boolean isEverythingOK = true;

                if(TextUtils.isEmpty(edtNom.getText().toString())){

                    edtNom.setError(getString(R.string.champ_obligatoire));
                    isEverythingOK = false;

                }
                if(TextUtils.isEmpty(edtPrenom.getText().toString())){

                    edtPrenom.setError(getString(R.string.champ_obligatoire));
                    isEverythingOK = false;

                }
                if(TextUtils.isEmpty(edtMail.getText().toString())){

                    edtMail.setError(getString(R.string.champ_obligatoire));
                    isEverythingOK = false;

                }

                if(TextUtils.isEmpty(edtStrtNbr.getText().toString())){

                    edtStrtNbr.setError(getString(R.string.champ_obligatoire));
                    isEverythingOK = false;

                }
                if(TextUtils.isEmpty(edtStrtNm.getText().toString())){

                    edtStrtNm.setError(getString(R.string.champ_obligatoire));
                    isEverythingOK = false;

                }
                if(TextUtils.isEmpty(edtCity.getText().toString())){

                    edtCity.setError(getString(R.string.champ_obligatoire));
                    isEverythingOK = false;

                }
                if(TextUtils.isEmpty(edtCP.getText().toString())){

                    edtCP.setError(getString(R.string.champ_obligatoire));
                    isEverythingOK = false;

                }

                if(isEverythingOK){

                    updateMyInfos(Urlbase.userInfo.getInt("idUser"));

                }

            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();

        getMyInfo(Urlbase.userInfo.getInt("idUser"));

    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    private void getMyInfo(Integer idUser){

        // Url pointant vers l'API et la fonction adéquate, ici ça sera la fonction de connection
        String url = new Urlbase().urlbase + "/getMyProfil";

        // Création d'un JSON qui va contenir les informations nécessaire à la connection
        // Donc ça sera le mail et le password de l'utilisateur
        // Et tout sera envoyé vers le serveur
        JSONObject userInfos = new JSONObject();
        try {
            userInfos.put("idUser", idUser);

        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();

            // Ici on gère l'erreur qui pourrait se présenter lors de la création du JSON
            // Et on affiche dans les logs l'erreur
            Log.e("getMyInfo","error making JSON: "+e);

        }

        // On créer la requête qui sera envoyer au serveur
        // Request.Method.POST: On attribut la méthode POST
        // url: L'URL du serveur et de la fonction de l'API
        // loginInfos: Les parametre à envoyer donc le JSON
        // Et enfin l'écouteur d'événement ou si vous préférez la réponse du serveur
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.POST, url, userInfos, new Response.Listener<JSONObject>() {

                    // Si on a une réponse alors on la  gère ici
                    @Override
                    public void onResponse(JSONObject response) {

                        // Gestion de la réponse du serveur
                        Log.e("getMyInfo","response: "+response);

                        try {

                            edtNom.setText(response.getString("nom"));
                            edtPrenom.setText(response.getString("prenom"));
                            edtMail.setText(response.getString("email"));

                            edtModel.setText(response.getString("modele"));
                            edtBrand.setText(response.getString("marque"));
                            edtColor.setText(response.getString("couleur"));
                            edtPlace.setText(response.getString("place"));

                            edtStrtNbr.setText(response.getString("numeroRue"));
                            edtStrtNm.setText(response.getString("nomRue"));
                            edtCity .setText(response.getString("ville"));
                            edtCP .setText(response.getString("codePostal"));

                            if(response.getInt("disponible") == 1){

                                hasCarAvailable.setChecked(true);

                            }
                            else{

                                hasCarAvailable.setChecked(false);

                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                    // Si on a une erreur on la gère ici et on pleure car il y a une erreur qui ne devrait pas être la mais il faut la gérer pour éviter le crash complet
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Log.e("volley error",""+error);

                        // Gestion de l'erreur
                        // S'il n'y a pas de connection internet alors on va gérer l'erreur ICI
                        if (error instanceof TimeoutError || error instanceof NoConnectionError) {

                        }

                        // si l'authentification n'est pas bonne on gére l'erreur ICI
                        else if (error instanceof AuthFailureError) {
                            //TODO
                        }

                        // Si le serveur est mort alors on gere ça ICI
                        else if (error instanceof ServerError) {
                            //TODO
                        }

                        // S'il y a un problème réseau... ICI
                        else if (error instanceof NetworkError) {
                            //TODO
                        }

                        // Et enfin s'il y a un problème de code côté serveur ça sera ICI !
                        else if (error instanceof ParseError) {
                            //TODO
                        }

                    }
                });

        // Ajout e la requete à la queue pour son envoie
        Volley.newRequestQueue(SettingsActivity.this).add(jsonObjectRequest);

    }

    private void updateMDP(Integer idUser, String oldPwd, String newPwd){

        // Url pointant vers l'API et la fonction adéquate, ici ça sera la fonction de connection
        String url = new Urlbase().urlbase + "/updatePassword";

        JSONObject userInfos = new JSONObject();
        try {
            userInfos.put("idUser", idUser);
            userInfos.put("oldPassword", oldPwd);
            userInfos.put("newPassword", newPwd);

        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();

            // Ici on gère l'erreur qui pourrait se présenter lors de la création du JSON
            // Et on affiche dans les logs l'erreur
            Log.e("updateMDP","error making JSON: "+e);

        }

        // On créer la requête qui sera envoyer au serveur
        // Request.Method.POST: On attribut la méthode POST
        // url: L'URL du serveur et de la fonction de l'API
        // loginInfos: Les parametre à envoyer donc le JSON
        // Et enfin l'écouteur d'événement ou si vous préférez la réponse du serveur
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.POST, url, userInfos, new Response.Listener<JSONObject>() {

                    // Si on a une réponse alors on la  gère ici
                    @Override
                    public void onResponse(JSONObject response) {

                        // Gestion de la réponse du serveur
                        Log.e("updateMDP","response: "+response);

                    }
                    // Si on a une erreur on la gère ici et on pleure car il y a une erreur qui ne devrait pas être la mais il faut la gérer pour éviter le crash complet
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Log.e("volley error",""+error);

                        // Gestion de l'erreur
                        // S'il n'y a pas de connection internet alors on va gérer l'erreur ICI
                        if (error instanceof TimeoutError || error instanceof NoConnectionError) {

                        }

                        // si l'authentification n'est pas bonne on gére l'erreur ICI
                        else if (error instanceof AuthFailureError) {
                            //TODO
                        }

                        // Si le serveur est mort alors on gere ça ICI
                        else if (error instanceof ServerError) {
                            //TODO
                        }

                        // S'il y a un problème réseau... ICI
                        else if (error instanceof NetworkError) {
                            //TODO
                        }

                        // Et enfin s'il y a un problème de code côté serveur ça sera ICI !
                        else if (error instanceof ParseError) {
                            //TODO
                        }

                    }
                });

        // Ajout e la requete à la queue pour son envoie
        Volley.newRequestQueue(SettingsActivity.this).add(jsonObjectRequest);

    }

    private void updateMyInfos(Integer idUser){

        // Url pointant vers l'API et la fonction adéquate, ici ça sera la fonction de connection
        String url = new Urlbase().urlbase + "/updateInfoUser";

        JSONObject userInfos = new JSONObject();
        try {

            userInfos.put("idUser", idUser);
            userInfos.put("nom", edtNom.getText().toString());
            userInfos.put("prenom", edtPrenom.getText().toString());
            userInfos.put("email", edtMail.getText().toString());

            userInfos.put("marque", edtBrand.getText().toString());
            userInfos.put("modele", edtModel.getText().toString());
            userInfos.put("couleur", edtColor.getText().toString());
            userInfos.put("place", edtPlace.getText().toString());

            if( hasCarAvailable.isChecked()){

                userInfos.put("isAvailable", hasCarAvailable.isChecked());

            }
            else{

                userInfos.put("isAvailable", 0);

            }

            userInfos.put("nomRue", edtStrtNm.getText().toString());
            userInfos.put("numeroRue", edtStrtNbr.getText().toString());
            userInfos.put("ville", edtCity.getText().toString());
            userInfos.put("codePostal", edtCP.getText().toString());

        } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();

            // Ici on gère l'erreur qui pourrait se présenter lors de la création du JSON
            // Et on affiche dans les logs l'erreur
            Log.e("updateMDP","error making JSON: "+e);

        }

        // On créer la requête qui sera envoyer au serveur
        // Request.Method.POST: On attribut la méthode POST
        // url: L'URL du serveur et de la fonction de l'API
        // loginInfos: Les parametre à envoyer donc le JSON
        // Et enfin l'écouteur d'événement ou si vous préférez la réponse du serveur
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.POST, url, userInfos, new Response.Listener<JSONObject>() {

                    // Si on a une réponse alors on la  gère ici
                    @Override
                    public void onResponse(JSONObject response) {

                        // Gestion de la réponse du serveur
                        Log.e("updateMDP","response: "+response);

                    }
                    // Si on a une erreur on la gère ici et on pleure car il y a une erreur qui ne devrait pas être la mais il faut la gérer pour éviter le crash complet
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Log.e("volley error",""+error.toString());

                        // Gestion de l'erreur
                        // S'il n'y a pas de connection internet alors on va gérer l'erreur ICI
                        if (error instanceof TimeoutError || error instanceof NoConnectionError) {

                        }

                        // si l'authentification n'est pas bonne on gére l'erreur ICI
                        else if (error instanceof AuthFailureError) {
                            //TODO
                        }

                        // Si le serveur est mort alors on gere ça ICI
                        else if (error instanceof ServerError) {
                            //TODO
                        }

                        // S'il y a un problème réseau... ICI
                        else if (error instanceof NetworkError) {
                            //TODO
                        }

                        // Et enfin s'il y a un problème de code côté serveur ça sera ICI !
                        else if (error instanceof ParseError) {
                            //TODO
                        }

                    }
                });

        // Ajout e la requete à la queue pour son envoie
        Volley.newRequestQueue(SettingsActivity.this).add(jsonObjectRequest);

    }

}
